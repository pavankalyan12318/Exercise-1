module.exports = {
    username: 'standard_user',
    password: 'secret_sauce',
    baseURL: 'https://www.saucedemo.com/'
};
